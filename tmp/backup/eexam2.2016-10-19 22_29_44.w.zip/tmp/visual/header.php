 
<P align="center">&nbsp;<IMG src="http://res.cloudinary.com/dl2hc8da3/image/upload/v1471676177/logo_ukqiuf.png" 
border="0"> </P>